/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bridge.ejb;

import java.util.List;
import javax.ejb.Stateless;
import javax.faces.model.DataModel;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.faces.bean.SessionScoped;
import javax.faces.model.ListDataModel;
import javax.inject.Named;
import javax.persistence.Query;
import bridge.entity.College;

//@Stateless
@Named
@SessionScoped
public class CollegeFacade extends AbstractFacade<College> {

    @PersistenceContext
    private EntityManager em;
     String keyword;

    public String getKeyword() {
        return keyword;
    }

    public void setKeyword(String keyword) {
        this.keyword = keyword;
    }
    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public CollegeFacade() {
        super(College.class);
    }
     public DataModel createPageDataModelByCollegeSearch() {
        Query query = em.createNamedQuery("College.findBySearch");
        keyword = "%" + keyword + "%";
        List<College> lists = query.setParameter("keyWord", keyword).getResultList();
        keyword = "";
        return new ListDataModel(lists);
    }
}
