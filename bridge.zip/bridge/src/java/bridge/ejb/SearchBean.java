/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bridge.ejb;

import java.io.Serializable;
import javax.ejb.Stateless;
import javax.faces.bean.SessionScoped;
import javax.inject.Named;

import bridge.entity.College;
import bridge.entity.Sharing;
import bridge.entity.User;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

@Named
@SessionScoped
@Stateless
public class SearchBean implements Serializable {

    @PersistenceContext
    private EntityManager em;
    private List<Sharing> results1 = null;
    private List<College> results2 = null;
    private List<User> results3 = null;


}
