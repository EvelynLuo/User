/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bridge.ejb;

import bridge.entity.Sharing;

import java.util.List;
import javax.ejb.Stateless;
import javax.faces.model.DataModel;
import javax.faces.model.ListDataModel;
import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

/**
 *
 * @author Stardust
 */
@Stateless

@Named
public class SharingFacade extends AbstractFacade<Sharing> {

    @PersistenceContext
    private EntityManager em;
 String keyword;

    public String getKeyword() {
        return keyword;
    }

    public void setKeyword(String keyword) {
        this.keyword = keyword;
    }
    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public SharingFacade() {
        super(Sharing.class);
    }
      public DataModel createPageDataModelBySharingSearch() {
        Query query = em.createNamedQuery("Sharing.findBySearch");
        keyword = "%" + keyword + "%";
        List<Sharing> lists = query.setParameter("keyWord", keyword).getResultList();
        keyword = "";
        return new ListDataModel(lists);
    }
   public DataModel createPageDataModelBySharingSearch_user(String key) {
        Query query = em.createNamedQuery("Sharing.findBySearch");
        key = "%" + key + "%";
        List<Sharing> lists = query.setParameter("keyWord", key).getResultList();
        key = "";
        return new ListDataModel(lists);
    }
     
    
    
}
