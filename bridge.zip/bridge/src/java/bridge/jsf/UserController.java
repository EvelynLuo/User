package bridge.jsf;

import bridge.entity.User;
import bridge.jsf.util.JsfUtil;
import bridge.jsf.util.PaginationHelper;
import bridge.ejb.UserFacade;
import bridge.ejb.UserInfoBean;
import bridge.entity.College;
import bridge.entity.Sharing;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.faces.bean.SessionScoped;
import javax.inject.Named;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.FacesConverter;
import javax.faces.model.DataModel;
import javax.faces.model.ListDataModel;
import javax.faces.model.SelectItem;

import javax.validation.constraints.NotNull;

@Named("userController")
@SessionScoped
@Stateless
public class UserController implements Serializable {

    private User current;
    private DataModel items = null;
    private User loginUser;

    @EJB
    private bridge.ejb.UserFacade ejbFacade;
    private PaginationHelper pagination;
    private int selectedItemIndex;

    @EJB
    private UserInfoBean userInfoBean;

    //backingbean
    @NotNull
    protected Integer uId;
    protected String uUsername;
    protected String uPassword;
    protected College collegeCId;
    protected int u_state;
    protected String uAvatar;

    //can be null    
    protected String uName;
    protected Long uGPA;
    protected Long uTofel;
    protected Long uGre;
    protected String uWechat;
    protected String uEmail;
    protected String uInfo;
    protected String uMajor;

    protected List<College> starred;
    
    //
    protected String searchInput;

    public String getSearchInput() {
        return searchInput;
    }

    public void setSearchInput(String searchInput) {
        this.searchInput = searchInput;
    }
    protected List<User>  reList;

    public List<User> getReList() {
        return reList;
    }

    public void setReList(List<User> reList) {
        this.reList = reList;
    }

    protected Collection<College> collegeCollection;
    protected Collection<Sharing> sharingCollection;
    private static final Logger logger = Logger.getLogger("bridge.web.UserController");

    protected int userId;
    protected String username;
    protected String password;

    public String validateUserLogin() {
        User attemptUser = ejbFacade.validateUser(this.username);
        if (attemptUser != null) {
            if (password.equals(attemptUser.getUPassword())) {
                this.userId = attemptUser.getUId();
                this.loginStatus = 1;
                this.loginUser = attemptUser;
                 logger.log(Level.INFO, "validateUserLogin");
                return "/index.xhtml";
            } else {
                this.loginStatus = 2;
                return "/login.xhtml";
            }
        } else {
            this.loginStatus = 3;
            return "/index.html";
        }
    }

    public User getLoginUser() {
        return loginUser;
    }

    public void setLoginUser(User loginUser) {
        this.loginUser = loginUser;
    }

    public void setLoginStatus(int loginStatus) {
        this.loginStatus = loginStatus;
    }
    protected int loginStatus = 0;

    public UserController() {
    }

    public User getSelected() {
        if (current == null) {
            current = new User();
            selectedItemIndex = -1;
        }
        return current;
    }

    private UserFacade getFacade() {
        return ejbFacade;
    }

    public PaginationHelper getPagination() {
        if (pagination == null) {
            pagination = new PaginationHelper(10) {

                @Override
                public int getItemsCount() {
                    return getFacade().count();
                }

                @Override
                public DataModel createPageDataModel() {
                    return new ListDataModel(getFacade().findRange(new int[]{getPageFirstItem(), getPageFirstItem() + getPageSize()}));
                }
            };
        }
        return pagination;
    }

    public String prepareList() {
        recreateModel();
        return "List";
    }

    public String prepareView() {
        current = (User) getItems().getRowData();
        selectedItemIndex = pagination.getPageFirstItem() + getItems().getRowIndex();
        return "/User/userInfoPage.xhtml";
    }
    
  


    public String prepareCreate() {
        current = new User();
        selectedItemIndex = -1;
        return "Create";
    }

    public String create() {
        try {
            getFacade().create(current);
            JsfUtil.addSuccessMessage(ResourceBundle.getBundle("/Bundle").getString("UserCreated"));
            return prepareCreate();
        } catch (Exception e) {
            JsfUtil.addErrorMessage(e, ResourceBundle.getBundle("/Bundle").getString("PersistenceErrorOccured"));
            return null;
        }
    }

    public String prepareEdit() {
        current = (User) getItems().getRowData();
        selectedItemIndex = pagination.getPageFirstItem() + getItems().getRowIndex();
        logger.log(Level.INFO, "prepareEdit: user_name: {0}", current.getUUsername());
        return "/User/Edit.xhtml";
    }

    public String update() {
        try {
            getFacade().edit(current);
            JsfUtil.addSuccessMessage(ResourceBundle.getBundle("/Bundle").getString("UserUpdated"));
            //！更新
           User user = setRealTimeData();
            logger.log(Level.INFO, "update: user_name: {0}", current.getUUsername());

            return "/User/userInfoPage.xhtml";
        } catch (Exception e) {
            JsfUtil.addErrorMessage(e, ResourceBundle.getBundle("/Bundle").getString("PersistenceErrorOccured"));
            return null;
        }
    }
    
    public User setRealTimeData(){
        User user = userInfoBean.getUserById(this.uId);

            this.uUsername = user.getUUsername();
            this.uName = user.getUName();

            this.uEmail = user.getUEmail();
            this.uWechat = user.getUWechat();
            this.uInfo = user.getUInfo();
            this.uMajor = user.getUMajor();
            this.u_state = user.getUState();
            this.collegeCId = user.getCollegeCId();
            this.uAvatar = user.getUAvatar();

            this.uTofel = user.getUTofel() != null ? user.getUTofel() : 0;
            this.uGre = user.getUGre() != null ? user.getUGre() : 0;
            this.uGPA = user.getUGre() != null ? user.getUGre() : 0;
            
            return user;
    }

    public String destroy() {
        current = (User) getItems().getRowData();
        selectedItemIndex = pagination.getPageFirstItem() + getItems().getRowIndex();
        performDestroy();
        recreatePagination();
        recreateModel();
        return "List";
    }

    public String destroyAndView() {
        performDestroy();
        recreateModel();
        updateCurrentItem();
        if (selectedItemIndex >= 0) {
            return "/User/userInfoPage.xhtml";
        } else {
            // all items were removed - go back to list
            recreateModel();
            return "List";
        }
    }

    private void performDestroy() {
        try {
            getFacade().remove(current);
            JsfUtil.addSuccessMessage(ResourceBundle.getBundle("/Bundle").getString("UserDeleted"));
        } catch (Exception e) {
            JsfUtil.addErrorMessage(e, ResourceBundle.getBundle("/Bundle").getString("PersistenceErrorOccured"));
        }
    }

    private void updateCurrentItem() {
        int count = getFacade().count();
        if (selectedItemIndex >= count) {
            // selected index cannot be bigger than number of items:
            selectedItemIndex = count - 1;
            // go to previous page if last page disappeared:
            if (pagination.getPageFirstItem() >= count) {
                pagination.previousPage();
            }
        }
        if (selectedItemIndex >= 0) {
            current = getFacade().findRange(new int[]{selectedItemIndex, selectedItemIndex + 1}).get(0);
        }
    }

    public DataModel getItems() {
        if (items == null) {
            items = getPagination().createPageDataModel();
        }
        return items;
    }

    private void recreateModel() {
        items = null;
    }

    private void recreatePagination() {
        pagination = null;
    }

    public String next() {
        getPagination().nextPage();
        recreateModel();
        return "List";
    }

    public String previous() {
        getPagination().previousPage();
        recreateModel();
        return "List";
    }

    public SelectItem[] getItemsAvailableSelectMany() {
        return JsfUtil.getSelectItems(ejbFacade.findAll(), false);
    }

    public SelectItem[] getItemsAvailableSelectOne() {
        return JsfUtil.getSelectItems(ejbFacade.findAll(), true);
    }

    public User getUser(java.lang.Integer id) {
        return ejbFacade.find(id);
    }

    @FacesConverter(forClass = User.class)
    public static class UserControllerConverter implements Converter {

        @Override
        public Object getAsObject(FacesContext facesContext, UIComponent component, String value) {
            if (value == null || value.length() == 0) {
                return null;
            }
            UserController controller = (UserController) facesContext.getApplication().getELResolver().
                    getValue(facesContext.getELContext(), null, "userController");
            return controller.getUser(getKey(value));
        }

        java.lang.Integer getKey(String value) {
            java.lang.Integer key;
            key = Integer.valueOf(value);
            return key;
        }

        String getStringKey(java.lang.Integer value) {
            StringBuilder sb = new StringBuilder();
            sb.append(value);
            return sb.toString();
        }

        @Override
        public String getAsString(FacesContext facesContext, UIComponent component, Object object) {
            if (object == null) {
                return null;
            }
            if (object instanceof User) {
                User o = (User) object;
                return getStringKey(o.getUId());
            } else {
                throw new IllegalArgumentException("object " + object + " is of type " + object.getClass().getName() + "; expected type: " + User.class.getName());
            }
        }
    }

    public String getUserInfoPage() {
        this.uId = Integer.parseInt(FacesContext.getCurrentInstance()
                .getExternalContext().getRequestParameterMap()
                .get("user_id"));
        logger.log(Level.INFO, "getPage():user_id: {0}", String.valueOf(this.uId));
        User user = setRealTimeData();
        logger.log(Level.INFO, "getUserInfoPage:user_name: {0}", user.getUUsername());
        getAllStarred(user);
        return "/User/userInfoPage.xhtml";
    }

    public String getLoginPage(){
        this.uId = Integer.parseInt(FacesContext.getCurrentInstance()
                .getExternalContext().getRequestParameterMap()
                .get("user_id"));
        logger.log(Level.INFO, "getLoginPage():user_id: {0}", String.valueOf(this.uId));
        User user = setRealTimeData();
        logger.log(Level.INFO, "getLoginPage:user_name: {0}", user.getUUsername());
        getAllStarred(user);
        return "/User/login.xhtml";
    }

    public void getAllStarred(User user) {
        this.starred = userInfoBean.getAllStarredColleges(user);
    }


    public User getCurrent() {
        return current;
    }

    public void setCurrent(User current) {
        this.current = current;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public int getLoginStatus() {
        return loginStatus;
    }

    public int getSelectedItemIndex() {
        return selectedItemIndex;
    }

    public void setSelectedItemIndex(int selectedItemIndex) {
        this.selectedItemIndex = selectedItemIndex;
    }

    public Integer getuId() {
        return uId;
    }

    public void setuId(Integer uId) {
        this.uId = uId;
    }

    public String getuUsername() {
        return uUsername;
    }

    public void setuUsername(String uUsername) {
        this.uUsername = uUsername;
    }

    public String getuPassword() {
        return uPassword;
    }

    public void setuPassword(String uPassword) {
        this.uPassword = uPassword;
    }

    public College getCollegeCId() {
        return collegeCId;
    }

    public void setCollegeCId(College collegeCId) {
        this.collegeCId = collegeCId;
    }

    public int getU_state() {
        return u_state;
    }

    public void setU_state(int u_state) {
        this.u_state = u_state;
    }

    public String getuAvatar() {
        return uAvatar;
    }

    public void setuAvatar(String uAvatar) {
        this.uAvatar = uAvatar;
    }

    public String getuName() {
        return uName;
    }

    public void setuName(String uName) {
        this.uName = uName;
    }

    public Long getuGPA() {
        return uGPA;
    }

    public void setuGPA(Long uGPA) {
        this.uGPA = uGPA;
    }

    public Long getuTofel() {
        return uTofel;
    }

    public void setuTofel(Long uTofel) {
        this.uTofel = uTofel;
    }

    public Long getuGre() {
        return uGre;
    }

    public void setuGre(Long uGre) {
        this.uGre = uGre;
    }

    public String getuWechat() {
        return uWechat;
    }

    public void setuWechat(String uWechat) {
        this.uWechat = uWechat;
    }

    public String getuEmail() {
        return uEmail;
    }

    public void setuEmail(String uEmail) {
        this.uEmail = uEmail;
    }

    public String getuInfo() {
        return uInfo;
    }

    public void setuInfo(String uInfo) {
        this.uInfo = uInfo;
    }

    public String getuMajor() {
        return uMajor;
    }

    public void setuMajor(String uMajor) {
        this.uMajor = uMajor;
    }

    public Collection<College> getCollegeCollection() {
        return collegeCollection;
    }

    public void setCollegeCollection(Collection<College> collegeCollection) {
        this.collegeCollection = collegeCollection;
    }

    public Collection<Sharing> getSharingCollection() {
        return sharingCollection;
    }

    public void setSharingCollection(Collection<Sharing> sharingCollection) {
        this.sharingCollection = sharingCollection;
    }

    public List<College> getStarred() {
        return starred;
    }

    public void setStarred(List<College> starred) {
        this.starred = starred;
    }
    

public String getItemsByUserSearch(){
            pagination = new PaginationHelper(10) {
                @Override
                public int getItemsCount() {
                    return getFacade().count();
                }
                @Override
                public DataModel createPageDataModel(){
                    return ejbFacade.createPageDataModelByUserSearch();
                }
            };
            items=pagination.createPageDataModel();
        
        return "List";
    }
public String refresh(){
items=null;
return "List";
}
        
       

}
