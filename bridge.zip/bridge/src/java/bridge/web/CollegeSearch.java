/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bridge.web;


import bridge.ejb.CollegeInfoBean;

import bridge.entity.CollegeShow;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;
import javax.inject.Named;


/**
 *
 * @author Jasmi
 */
@Named
@SessionScoped
@Stateless
public class CollegeSearch implements Serializable {
      @EJB
    private CollegeInfoBean collegeInfoBean;
       
      protected List<CollegeShow> CInfo = new ArrayList<>();
     public String scearch_process(String keyword) {
       
          FacesContext context = FacesContext.getCurrentInstance(); 
         CollegeInfo collegeInfo = (CollegeInfo) context.getApplication().createValueBinding("#{collegeInfo}").getValue(context);   
        collegeInfo.setCInfo(collegeInfoBean.processInfo_search(keyword));
        return "/college/collegeListPage.xhtml";
    }
   
    public String refresh(){
 this.CInfo = collegeInfoBean.processInfo_default();
        return "/college/collegeListPage.xhtml";
}
       
      

   
          
}

