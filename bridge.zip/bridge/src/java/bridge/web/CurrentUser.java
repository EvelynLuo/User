/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bridge.web;

import bridge.ejb.UserInfoBean;
import bridge.entity.User;
import java.io.Serializable;
import javax.ejb.EJB;
import javax.faces.bean.SessionScoped;
import javax.inject.Named;

/**
 *
 * @author Jasmi
 */
@Named
@SessionScoped
public class CurrentUser implements Serializable {

    @EJB
    private UserInfoBean userInfoBean;

    protected int userId;
    protected String username;
    protected String password;
    protected int loginStatus = 0;

    /*
    0: haven't logged in
    1: successfully logged in
    2: wrong password
    3: user does not exist
     */
    public CurrentUser() {
    }

    public String validateUserLogin() {
        User attemptUser = userInfoBean.validateUser(this.username);
        if (attemptUser != null) {
            if (password.equals(attemptUser.getUPassword())) {
                this.userId = attemptUser.getUId();
                this.loginStatus = 1;
                return "/index.xhtml";
            } else {
                this.loginStatus = 2;
                return "/login.xhtml";
            }
        }
        else {
            this.loginStatus = 3;
            return "/index.html";
        }
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public int getLoginStatus() {
        return loginStatus;
    }

}
