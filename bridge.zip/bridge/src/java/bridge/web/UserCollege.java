/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bridge.web;

import javax.ejb.EJB;
import javax.inject.Named;
import bridge.ejb.CollegeInfoBean;
import bridge.ejb.UserInfoBean;
import bridge.entity.College;
import bridge.entity.User;
import java.io.Serializable;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;
import javax.persistence.PersistenceContext;

/**
 *
 * @author Jasmi
 */
@Named
@SessionScoped
public class UserCollege implements Serializable {

    @EJB
    private CollegeInfoBean collegeInfoBean;
    @EJB
    private UserInfoBean userInfoBean;

    protected int cId;
    protected int uId;
    protected String bookmarkStatus;

    public String userStarsCollege() {
        this.cId = Integer.parseInt(FacesContext.getCurrentInstance()
                .getExternalContext().getRequestParameterMap()
                .get("cur_college_id"));
        this.uId = Integer.parseInt(FacesContext.getCurrentInstance()
                .getExternalContext().getRequestParameterMap()
                .get("cur_user_id"));

        College college = collegeInfoBean.getCollegeById(this.cId);
        User user = userInfoBean.getUserById(this.uId);
        college.getUserCollection().add(user);
        
        if (collegeInfoBean.addStars(college)) {
            bookmarkStatus = "Bookmarked!";
        } 
        else {
            bookmarkStatus = "Bookmark failed!";
        }
        
        CollegeInfo collegeInfo = (CollegeInfo) FacesContext.getCurrentInstance()
                                  .getExternalContext().getSessionMap().get("collegeInfo");
        collegeInfo.refreshStars();
        
        return "/college/collegeInfoPage.xhtml";
    }

    public int getcId() {
        return cId;
    }

    public void setcId(int cId) {
        this.cId = cId;
    }

    public int getuId() {
        return uId;
    }

    public void setuId(int uId) {
        this.uId = uId;
    }

}
